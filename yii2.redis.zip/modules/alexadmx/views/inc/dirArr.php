<?php
return [
    'runtime/cache/',
    'runtime/logs/',
    'runtime/debug/',
    'runtime/mail/',
    'runtime/HTML/',
    'runtime/URI/',
    'web/minify/',
//    'web/assets/',
];
